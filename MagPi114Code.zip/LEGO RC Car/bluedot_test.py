from bluedot import BlueDot
dot = BlueDot()

print('Waiting...')
dot.wait_for_press()
print("It worked!")